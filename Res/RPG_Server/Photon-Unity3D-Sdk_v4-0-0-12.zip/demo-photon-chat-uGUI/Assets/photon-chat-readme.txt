
Photon Chat
    This package contains Photon Chat as standalone product.
    A simple uGui is implemented as showcase and basis for integration in any game or application.
    

Compatibility
    Photon Chat is included in most other Photon Product packages. 
    Do not import this package into PUN, or the Photon Unity SDK. The API is already there.


Documentation and Help 
    The Chat API reference and documentation is online.
    
    Reference:
    http://doc-api.photonengine.com/en/realtime/current/dotnet/doc/md_doxygen_chat.html
    
    Manuals and general doc:
    http://doc.photonengine.com/en/chat/current
    
    Dashboard:
    https://www.photonengine.com/en/Chat/Dashboard
    
	Support Forum:
    http://forum.photonengine.com/categories/photon-chat

